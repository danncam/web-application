package net.webapp.entity;

public class StdLogin {

	private String username;
	private String password;
	private boolean valid;
	
	public void setUserName(String username) {
		this.username = username;
	}
	
	public String getUsername() {
        return username;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	 public String getPassword() {
         return password;
	}
	 
	public boolean isValid() {
		
		return valid;
	}
	
	public void setValid(boolean value) {
        valid = value;
	}	

}
