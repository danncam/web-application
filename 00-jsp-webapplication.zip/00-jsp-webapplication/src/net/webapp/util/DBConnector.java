package net.webapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnector {
	
	//Define the database properties
	private static final String URL = "jdbc:mysql://localhost:3306/";
	private static final String DBNAME = "testdir";
	private static final String TIMEZONE = "?useTimezone=true&serverTimezone=UTC";
	private static final String DRIVER = "com.mysql.jdbc.Driver";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "root";
	private static Connection connection = null;
	private static Statement statement = null;
	private static ResultSet resultSet = null;
	
	public DBConnector() {
		
	}
	
	//Get the database connection
	public static void openConnection() {
		try {
			Class.forName(DRIVER);
            connection = DriverManager.getConnection(URL+DBNAME+TIMEZONE, USERNAME, PASSWORD);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}
	
	public static void getStatement() {
		if(statement == null) {
			try {
				statement = connection.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void execute(String sql) {
		try {
			resultSet = statement.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static String getDataBaseName() {
		return DBNAME;
	}
}
